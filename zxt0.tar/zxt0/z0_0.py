import zxt1.a1
import zxt1.zxt2.a2
import zxt1.zxt2.zxt3.a3

if __name__ == '__main__':
    zxt1.a1.test()
    zxt1.zxt2.a2.test()
    zxt1.zxt2.zxt3.a3.test()
