import os


def test():
    fullname = os.path.realpath(__file__)
    basename, filename = os.path.split(fullname)
    # print('fullname:', fullname)
    # print('basename:', basename)
    print('filename:', filename)


if __name__ == '__main__':
    test()
