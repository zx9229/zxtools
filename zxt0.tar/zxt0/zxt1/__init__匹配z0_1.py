import zxt1.a1
import zxt1.zxt2.a2
import zxt1.zxt2.zxt3.a3
# 在我们执行import时，当前目录是不会变的（就算是执行子目录的文件），还是需要完整的包名。
