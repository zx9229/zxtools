import a1
import zxt2.a2
import zxt2.zxt3.a3

if __name__ == '__main__':
    a1.test()
    zxt2.a2.test()
    zxt2.zxt3.a3.test()
