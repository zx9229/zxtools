# Python __init__.py 作用详解
# https://www.cnblogs.com/Lands-ljk/p/5880483.html
# 有以下几种导入方式：
# import subpackage1.a # 将模块subpackage.a导入全局命名空间，例如访问a中属性时用subpackage1.a.attr
# from subpackage1 import a #　将模块a导入全局命名空间，例如访问a中属性时用a.attr_a
# from subpackage.a import attr_a # 将模块a的属性直接导入到命名空间中，例如访问a中属性时直接用attr_a
from zxt3 import a3, b3

if __name__ == '__main__':
    a3.test()
    b3.test()
