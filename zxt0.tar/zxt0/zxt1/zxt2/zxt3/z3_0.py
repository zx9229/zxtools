import a3, b3

if __name__ == '__main__':
    a3.test()
    b3.test()
