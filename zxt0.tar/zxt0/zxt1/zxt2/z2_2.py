import zxt3.a3, zxt3.b3

if __name__ == '__main__':
    zxt3.a3.test()
    zxt3.b3.test()
