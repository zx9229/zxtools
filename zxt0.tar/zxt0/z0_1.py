# 令文件 zxt1\__init__.py 的内容为:
# import zxt1.a1
# import zxt1.zxt2.a2
# import zxt1.zxt2.zxt3.a3
# 则可以如下书写:

import zxt1

if __name__ == '__main__':
    zxt1.a1.test()
    zxt1.zxt2.a2.test()
    zxt1.zxt2.zxt3.a3.test()
